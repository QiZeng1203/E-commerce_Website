import { PaymentInfo } from './payment-info';

describe('PaymentInfo', () => {
  it('should create an instance', () => {
    expect(new PaymentInfo()).toBeTruthy();
  });
});
