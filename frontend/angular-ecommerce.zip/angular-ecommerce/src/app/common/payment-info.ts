export class PaymentInfo {
    amount: number;
    currency: string;
    receiptEmail: string;
}
